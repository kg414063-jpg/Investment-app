# Investment Platform (Vercel-Ready)

This project is a **Next.js + Supabase + NOWPayments** investment dashboard ready for deployment on **Vercel**.

---
## 🚀 Quick Start

### 1. Prerequisites
- Node.js 18+
- Supabase account (https://supabase.com)
- NOWPayments account (https://nowpayments.io)
- Vercel account (https://vercel.com)

---
## 🧩 Supabase Setup

1. Create a new Supabase project.
2. In the SQL Editor, paste and run the contents of `supabase.sql`.
3. This creates the required tables and adds a default admin user.

**Default Admin Credentials**
```
Email: admin@example.com
Password: admin123
```

---
## ⚙️ Environment Variables (add these in Vercel)

```
NEXT_PUBLIC_SUPABASE_URL=your_supabase_url
SUPABASE_SERVICE_ROLE_KEY=your_service_role_key
JWT_SECRET=your_long_secret_string
NOWPAYMENTS_API_KEY=your_nowpayments_api_key
NOWPAYMENTS_WEBHOOK_SECRET=your_webhook_secret
```

---
## 🧱 Local Development

```bash
npm install
npm run dev
```
Then open [http://localhost:3000](http://localhost:3000)

---
## ☁️ Deploying to Vercel

1. Go to [vercel.com](https://vercel.com) → Import Project → Upload this ZIP.
2. Ensure `Framework Preset` = **Next.js**.
3. Confirm **Build Command** = `npm run build` and **Output Directory** = `.next`.
4. Add the environment variables above in the Vercel dashboard.
5. Deploy!

Your site will be live within minutes.

---
## 💰 Crypto Payments (NOWPayments)

1. Get your API key from NOWPayments.
2. Set your webhook URL in NOWPayments to:

```
https://<your-vercel-domain>/api/payments/webhook
```

3. Use the same secret as `NOWPAYMENTS_WEBHOOK_SECRET`.
4. Test the payment flow — successful payments will be logged to Supabase.

---
## 🧠 Notes

- The backend uses Supabase for user auth and transaction storage.
- Crypto payments are handled via NOWPayments API + webhook.
- The app is designed for deployment on Vercel (serverless-ready).

Enjoy building 🚀
