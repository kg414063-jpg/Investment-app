import {useEffect, useState} from 'react'
export default function Dashboard() {
  const [data, setData] = useState(null)
  useEffect(()=>{
    const tok = typeof window !== 'undefined' ? localStorage.getItem('token') : null
    fetch('http://localhost:8080/api/dashboard', {headers: { Authorization: `Bearer ${tok}` }}).then(r=>r.json()).then(setData)
  },[])
  if (!data) return <div>Loading...</div>
  return (
    <main style={{maxWidth:1000, margin:'40px auto'}}>
      <h1>Dashboard</h1>
      <div>Wallet balance: {data.wallet_balance}</div>
      <div>Investments: {data.investments_count}</div>
      <div>Total returns: {data.total_returns}</div>
    </main>
  )
}
