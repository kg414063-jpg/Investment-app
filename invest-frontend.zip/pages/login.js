import {useState} from 'react'
import Router from 'next/router'
export default function Login() {
  const [email, setEmail] = useState('')
  const [password, setPassword] = useState('')
  async function submit(e) {
    e.preventDefault()
    const res = await fetch('/api/login', {method:'POST', headers:{'Content-Type':'application/json'}, body: JSON.stringify({email,password})})
    const data = await res.json()
    if (res.ok) {
      if (typeof window !== 'undefined') localStorage.setItem('token', data.token)
      Router.push('/dashboard')
    } else {
      alert(data.error || 'Login failed')
    }
  }
  return (
    <main style={{maxWidth:500, margin:'60px auto'}}>
      <h1>Login</h1>
      <form onSubmit={submit}>
        <div><input placeholder='Email' value={email} onChange={e=>setEmail(e.target.value)} /></div>
        <div><input placeholder='Password' type='password' value={password} onChange={e=>setPassword(e.target.value)} /></div>
        <button type='submit'>Log in</button>
      </form>
    </main>
  )
}
