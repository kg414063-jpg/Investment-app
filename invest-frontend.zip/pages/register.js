import {useState} from 'react'
import Router from 'next/router'
export default function Register() {
  const [email, setEmail] = useState('')
  const [password, setPassword] = useState('')
  async function submit(e) {
    e.preventDefault()
    const res = await fetch('http://localhost:8080/api/signup', {method:'POST', headers:{'Content-Type':'application/json'}, body: JSON.stringify({email,password})})
    const data = await res.json()
    if (res.ok) {
      localStorage.setItem('token', data.token)
      Router.push('/dashboard')
    } else {
      alert(data.error || 'Register failed')
    }
  }
  return (
    <main style={{maxWidth:500, margin:'60px auto'}}>
      <h1>Register</h1>
      <form onSubmit={submit}>
        <div><input placeholder='Email' value={email} onChange={e=>setEmail(e.target.value)} /></div>
        <div><input placeholder='Password' type='password' value={password} onChange={e=>setPassword(e.target.value)} /></div>
        <button type='submit'>Sign up</button>
      </form>
    </main>
  )
}
