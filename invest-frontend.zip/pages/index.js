import Link from 'next/link'
export default function Home() {
  return (
    <main style={{maxWidth: 900, margin: '40px auto', fontFamily: 'system-ui, sans-serif'}}>
      <header style={{display:'flex', justifyContent:'space-between', alignItems:'center'}}>
        <h1>Investment</h1>
        <div>
          <Link href="/login">Login</Link>
          {' | '}
          <Link href="/register">Register</Link>
        </div>
      </header>
      <section style={{marginTop:40}}>
        <h2 style={{fontSize:48}}>Secure Your Investments</h2>
        <p>Invest your money with confidence and watch your wealth grow.</p>
      </section>
    </main>
  )
}
