import {useEffect, useState} from 'react'
export default function Transactions() {
  const [txs, setTxs] = useState([])
  useEffect(()=>{
    const tok = typeof window !== 'undefined' ? localStorage.getItem('token') : null
    fetch('http://localhost:8080/api/transactions', {headers: { Authorization: `Bearer ${tok}` }}).then(r=>r.json()).then(d=>setTxs(d.transactions||[]))
  },[])
  return (
    <main style={{maxWidth:900, margin:'40px auto'}}>
      <h1>Transactions</h1>
      <ul>{txs.map(t=> <li key={t.id}>{t.type} — {t.amount} — {new Date(t.created_at).toLocaleString()}</li>)}</ul>
    </main>
  )
}
