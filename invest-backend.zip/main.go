package main

import (
    "context"
    "database/sql"
    "encoding/json"
    "fmt"
    "log"
    "net/http"
    "time"

    "github.com/gin-gonic/gin"
    _ "github.com/lib/pq"
    bolt "go.etcd.io/bbolt"
)

const (
    boltFile   = "auth.db"
    boltBucket = "users"
)

type Server struct {
    db        *sql.DB
    bolt      *bolt.DB
    jwtSecret []byte
)

type UserRecord struct {
    ID       string `json:"id"`
    Email    string `json:"email"`
    PassHash []byte `json:"pass_hash"`
}

func newServer() (*Server, error) {
    // adjust your Postgres connection string: replace with your credentials before running
    db, err := sql.Open("postgres", "postgres://postgres:password@localhost:5432/investdb?sslmode=disable")
    if err != nil {
        return nil, err
    }
    db.SetMaxOpenConns(20)
    db.SetConnMaxIdleTime(time.Minute * 5)

    b, err := bolt.Open(boltFile, 0600, &bolt.Options{Timeout: 1 * time.Second})
    if err != nil {
        return nil, err
    }

    err = b.Update(func(tx *bolt.Tx) error {
        _, err := tx.CreateBucketIfNotExists([]byte(boltBucket))
        return err
    })
    if err != nil {
        return nil, err
    }

    s := &Server{
        db:        db,
        bolt:      b,
        jwtSecret: []byte("replace-with-strong-secret"),
    }
    return s, nil
}

func (s *Server) Close() {
    if s.bolt != nil {
        s.bolt.Close()
    }
    if s.db != nil {
        s.db.Close()
    }
}

func main() {
    srv, err := newServer()
    if err != nil {
        log.Fatal(err)
    }
    defer srv.Close()

    r := gin.Default()

    r.POST("/api/signup", srv.handleSignup)
    r.POST("/api/login", srv.handleLogin)

    auth := r.Group("/api")
    auth.Use(srv.jwtMiddleware())
    {
        auth.GET("/dashboard", srv.handleDashboard)
        auth.POST("/investments", srv.handleCreateInvestment)
        auth.POST("/deposit", srv.handleDeposit)
        auth.GET("/transactions", srv.handleTransactions)
    }

    log.Println("server listening at :8080")
    r.Run(":8080")
}
