package main

import (
    "context"
    "crypto/rand"
    "database/sql"
    "encoding/json"
    "errors"
    "fmt"
    "time"

    "github.com/gin-gonic/gin"
    "github.com/golang-jwt/jwt/v5"
    bolt "go.etcd.io/bbolt"
    "golang.org/x/crypto/bcrypt"
)

func uuidV4() (string, error) {
    b := make([]byte, 16)
    _, err := rand.Read(b)
    if err != nil {
        return "", err
    }
    b[6] = (b[6] & 0x0f) | 0x40
    b[8] = (b[8] & 0x3f) | 0x80
    return fmt.Sprintf("%x-%x-%x-%x-%x", b[0:4], b[4:6], b[6:8], b[8:10], b[10:]), nil
}

func (s *Server) createUserInBolt(email, password string) (*UserRecord, error) {
    passHash, err := bcrypt.GenerateFromPassword([]byte(password), bcrypt.DefaultCost)
    if err != nil {
        return nil, err
    }

    id, err := uuidV4()
    if err != nil {
        return nil, err
    }

    rec := &UserRecord{ID: id, Email: email, PassHash: passHash}
    buff, _ := json.Marshal(rec)

    err = s.bolt.Update(func(tx *bolt.Tx) error {
        b := tx.Bucket([]byte(boltBucket))
        if b.Get([]byte(email)) != nil {
            return errors.New("email exists")
        }
        return b.Put([]byte(email), buff)
    })
    if err != nil {
        return nil, err
    }

    _, err = s.db.Exec(`INSERT INTO app_users (id, email) VALUES ($1,$2)`, rec.ID, rec.Email)
    if err != nil {
        return nil, err
    }

    _, err = s.db.Exec(`INSERT INTO wallets (owner_id, balance) VALUES ($1, $2)`, rec.ID, 0)
    if err != nil {
        return nil, err
    }

    return rec, nil
}

func (s *Server) findUserByEmail(email string) (*UserRecord, error) {
    var rec UserRecord
    err := s.bolt.View(func(tx *bolt.Tx) error {
        b := tx.Bucket([]byte(boltBucket))
        v := b.Get([]byte(email))
        if v == nil {
            return sql.ErrNoRows
        }
        return json.Unmarshal(v, &rec)
    })
    if err != nil {
        return nil, err
    }
    return &rec, nil
}

func (s *Server) generateJWT(userID string, email string) (string, error) {
    now := time.Now()
    claims := jwt.MapClaims{
        "sub":   userID,
        "email": email,
        "iat":   now.Unix(),
        "exp":   now.Add(24 * time.Hour).Unix(),
    }
    token := jwt.NewWithClaims(jwt.SigningMethodHS256, claims)
    return token.SignedString(s.jwtSecret)
}

type signupReq struct {
    Email    string `json:"email"`
    Password string `json:"password"`
}

func (s *Server) handleSignup(c *gin.Context) {
    var req signupReq
    if err := c.BindJSON(&req); err != nil {
        c.JSON(400, gin.H{"error": "invalid"})
        return
    }
    rec, err := s.createUserInBolt(req.Email, req.Password)
    if err != nil {
        c.JSON(400, gin.H{"error": err.Error()})
        return
    }
    tok, err := s.generateJWT(rec.ID, rec.Email)
    if err != nil {
        c.JSON(500, gin.H{"error": "jwt error"})
        return
    }
    c.JSON(201, gin.H{"token": tok, "user_id": rec.ID})
}

type loginReq struct {
    Email    string `json:"email"`
    Password string `json:"password"`
}

func (s *Server) handleLogin(c *gin.Context) {
    var req loginReq
    if err := c.BindJSON(&req); err != nil {
        c.JSON(400, gin.H{"error": "invalid"})
        return
    }
    rec, err := s.findUserByEmail(req.Email)
    if err != nil {
        c.JSON(401, gin.H{"error": "invalid credentials"})
        return
    }
    if err := bcrypt.CompareHashAndPassword(rec.PassHash, []byte(req.Password)); err != nil {
        c.JSON(401, gin.H{"error": "invalid credentials"})
        return
    }
    tok, err := s.generateJWT(rec.ID, rec.Email)
    if err != nil {
        c.JSON(500, gin.H{"error": "jwt error"})
        return
    }
    c.JSON(200, gin.H{"token": tok, "user_id": rec.ID})
}

// WithUserTx helper and endpoints (dashboard, deposit, investments, transactions)
func (s *Server) WithUserTx(ctx context.Context, userID string, fn func(*sql.Tx) error) error {
    tx, err := s.db.BeginTx(ctx, nil)
    if err != nil {
        return err
    }

    if _, err := tx.ExecContext(ctx, "SET LOCAL app.user_id = $1", userID); err != nil {
        tx.Rollback()
        return err
    }

    if err := fn(tx); err != nil {
        tx.Rollback()
        return err
    }
    return tx.Commit()
}

func (s *Server) handleDashboard(c *gin.Context) {
    userID := c.GetString("user_id")
    ctx := c.Request.Context()

    var walletBalance sql.NullString
    var investmentsCount int
    var totalReturns sql.NullString

    err := s.WithUserTx(ctx, userID, func(tx *sql.Tx) error {
        if err := tx.QueryRowContext(ctx, `SELECT balance::text FROM wallets LIMIT 1`).Scan(&walletBalance); err != nil && err != sql.ErrNoRows {
            return err
        }
        if err := tx.QueryRowContext(ctx, `SELECT COUNT(*) FROM investments`).Scan(&investmentsCount); err != nil {
            return err
        }
        if err := tx.QueryRowContext(ctx, `SELECT COALESCE(SUM(amount)::text,'0') FROM transactions WHERE type='interest'`).Scan(&totalReturns); err != nil && err != sql.ErrNoRows {
            return err
        }
        return nil
    })
    if err != nil {
        c.JSON(500, gin.H{"error": err.Error()})
        return
    }
    c.JSON(200, gin.H{"wallet_balance": walletBalance.String, "investments_count": investmentsCount, "total_returns": totalReturns.String})
}

type createInvestReq struct {
    Name   string  `json:"name"`
    Amount float64 `json:"amount"`
}

func (s *Server) handleCreateInvestment(c *gin.Context) {
    userID := c.GetString("user_id")
    var req createInvestReq
    if err := c.BindJSON(&req); err != nil {
        c.JSON(400, gin.H{"error": "invalid"})
        return
    }
    ctx := c.Request.Context()
    err := s.WithUserTx(ctx, userID, func(tx *sql.Tx) error {
        _, err := tx.ExecContext(ctx, `INSERT INTO investments (owner_id, name, amount_invested) VALUES ($1,$2,$3)`, userID, req.Name, req.Amount)
        return err
    })
    if err != nil {
        c.JSON(500, gin.H{"error": err.Error()})
        return
    }
    c.JSON(201, gin.H{"ok": true})
}

type depositReq struct {
    Amount float64 `json:"amount"`
}

func (s *Server) handleDeposit(c *gin.Context) {
    userID := c.GetString("user_id")
    var req depositReq
    if err := c.BindJSON(&req); err != nil {
        c.JSON(400, gin.H{"error": "invalid"})
        return
    }
    ctx := c.Request.Context()
    err := s.WithUserTx(ctx, userID, func(tx *sql.Tx) error {
        var walletID string
        if err := tx.QueryRowContext(ctx, `SELECT id FROM wallets LIMIT 1`).Scan(&walletID); err != nil {
            return err
        }
        if _, err := tx.ExecContext(ctx, `UPDATE wallets SET balance = balance + $1, updated_at = now() WHERE id = $2`, req.Amount, walletID); err != nil {
            return err
        }
        if _, err := tx.ExecContext(ctx, `INSERT INTO transactions (owner_id,wallet_id,type,amount) VALUES ($1,$2,'deposit',$3)`, userID, walletID, req.Amount); err != nil {
            return err
        }
        return nil
    })
    if err != nil {
        c.JSON(500, gin.H{"error": err.Error()})
        return
    }
    c.JSON(200, gin.H{"ok": true})
}

func (s *Server) handleTransactions(c *gin.Context) {
    userID := c.GetString("user_id")
    ctx := c.Request.Context()
    txList := []map[string]interface{}{}
    err := s.WithUserTx(ctx, userID, func(tx *sql.Tx) error {
        rows, err := tx.QueryContext(ctx, `SELECT id,type,amount,created_at,metadata FROM transactions ORDER BY created_at DESC LIMIT 100`)
        if err != nil {
            return err
        }
        defer rows.Close()
        for rows.Next() {
            var id, t string
            var amt float64
            var created time.Time
            var meta []byte
            rows.Scan(&id, &t, &amt, &created, &meta)
            var m interface{}
            json.Unmarshal(meta, &m)
            txList = append(txList, map[string]interface{}{"id": id, "type": t, "amount": amt, "created_at": created, "metadata": m})
        }
        return rows.Err()
    })
    if err != nil {
        c.JSON(500, gin.H{"error": err.Error()})
        return
    }
    c.JSON(200, gin.H{"transactions": txList})
}

func (s *Server) jwtMiddleware() gin.HandlerFunc {
    return func(c *gin.Context) {
        auth := c.GetHeader("Authorization")
        if auth == "" {
            c.AbortWithStatusJSON(http.StatusUnauthorized, gin.H{"error": "missing auth"})
            return
        }
        var tokenString string
        fmt.Sscanf(auth, "Bearer %s", &tokenString)
        token, err := jwt.Parse(tokenString, func(t *jwt.Token) (interface{}, error) {
            if _, ok := t.Method.(*jwt.SigningMethodHMAC); !ok {
                return nil, fmt.Errorf("unexpected signing method")
            }
            return s.jwtSecret, nil
        })
        if err != nil || !token.Valid {
            c.AbortWithStatusJSON(http.StatusUnauthorized, gin.H{"error": "invalid token"})
            return
        }
        claims, ok := token.Claims.(jwt.MapClaims)
        if !ok {
            c.AbortWithStatusJSON(http.StatusUnauthorized, gin.H{"error": "bad claims"})
            return
        }
        sub, ok := claims["sub"].(string)
        if !ok {
            c.AbortWithStatusJSON(http.StatusUnauthorized, gin.H{"error": "no sub"})
            return
        }
        c.Set("user_id", sub)
        c.Next()
    }
}
