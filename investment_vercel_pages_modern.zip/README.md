# Investment Dashboard — Modern Pages Router (Vercel-ready)

This project uses the Next.js **Pages Router** (no /app directory) and is modernized for clarity and production deployment on Vercel.
It includes:
- Pages Router structure (pages/)
- Supabase (server-side) integration for persistence
- NOWPayments integration for crypto payments (invoice creation + webhook handler)
- Signup + Login flows, dashboard, and admin panel
- Mobile-responsive, clean UI (vanilla CSS)

## Setup
1. Create a Supabase project and run `supabase.sql` to create tables.
2. Add environment variables to Vercel (or `.env.local` for development):
   - `NEXT_PUBLIC_SUPABASE_URL`
   - `SUPABASE_SERVICE_ROLE_KEY`
   - `JWT_SECRET`
   - `NOWPAYMENTS_API_KEY`
   - `NOWPAYMENTS_WEBHOOK_SECRET`
3. `npm install`
4. `npm run dev` (local)
5. Deploy to Vercel (connect repo), ensure env vars are set in Vercel settings.

Important: Use Supabase service role key only on server-side (Vercel env). For production, rotate keys and secure them.
