import { supabase } from '../../../lib/supabase'
import bcrypt from 'bcryptjs'
import jwt from 'jsonwebtoken'
import cookie from 'cookie'

export default async function handler(req,res){
  if(req.method!=='POST') return res.status(405).end()
  const {email,name,password} = req.body || {}
  if(!email || !password) return res.status(400).json({error:'missing'})
  const hash = bcrypt.hashSync(password,10)
  const { data, error } = await supabase.from('users').insert([{ email, name, password_hash: hash }]).select('*').single()
  if(error) return res.status(400).json({error:'db'})
  const secret = process.env.JWT_SECRET || 'dev_secret'
  const token = jwt.sign({id:data.id,email:data.email,role:data.role}, secret, {expiresIn:'8h'})
  res.setHeader('Set-Cookie', cookie.serialize('token', token, {httpOnly:true, path:'/', maxAge:60*60*8}))
  res.status(200).json({ok:true})
}
