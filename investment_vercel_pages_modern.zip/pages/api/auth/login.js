import { supabase } from '../../../lib/supabase'
import bcrypt from 'bcryptjs'
import jwt from 'jsonwebtoken'
import cookie from 'cookie'

export default async function handler(req,res){
  if(req.method!=='POST') return res.status(405).end()
  const {email,password} = req.body || {}
  const { data, error } = await supabase.from('users').select('*').eq('email', email).limit(1).single()
  if(error || !data) return res.status(401).json({error:'Invalid'})
  const ok = bcrypt.compareSync(password, data.password_hash)
  if(!ok) return res.status(401).json({error:'Invalid'})
  const secret = process.env.JWT_SECRET || 'dev_secret'
  const token = jwt.sign({id:data.id,email:data.email,role:data.role}, secret, {expiresIn:'8h'})
  // Secure cookie flags: secure only on production (Vercel)
  const cookieStr = cookie.serialize('token', token, {httpOnly:true, path:'/', maxAge:60*60*8, secure: process.env.VERCEL_ENV === 'production', sameSite: 'lax'})
  res.setHeader('Set-Cookie', cookieStr)
  res.status(200).json({ok:true})
}
