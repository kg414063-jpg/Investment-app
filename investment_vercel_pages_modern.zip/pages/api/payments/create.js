import NowPayments from '@nowpaymentsio/nowpayments-api-js'
import { supabase } from '../../../lib/supabase'
import jwt from 'jsonwebtoken'

export default async function handler(req,res){
  if(req.method!=='POST') return res.status(405).end()
  const token = req.cookies?.token
  const secret = process.env.JWT_SECRET || 'dev_secret'
  let user = null
  try{ if(token) user = jwt.verify(token, secret) }catch(e){}
  if(!user) return res.status(401).json({error:'unauth'})
  const {amount, currency='usd', order_id} = req.body || {}
  if(!amount) return res.status(400).json({error:'missing amount'})
  const client = new NowPayments({ apiKey: process.env.NOWPAYMENTS_API_KEY })
  try{
    const invoice = await client.createPayment({ price_amount: amount, price_currency: currency.toUpperCase(), pay_currency: 'btc', order_id: order_id || `order_${Date.now()}` })
    await supabase.from('transactions').insert([{ user_id: user.id, amount, status: 'pending', provider: 'nowpayments', provider_id: invoice.id }])
    return res.status(200).json({invoice})
  }catch(e){
    console.error(e)
    return res.status(500).json({error:'provider'})
  }
}
