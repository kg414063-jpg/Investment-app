import { supabase } from '../../../lib/supabase'
import crypto from 'crypto'

export const config = { api: { bodyParser: false } }

async function buffer(stream){
  return new Promise((resolve, reject) => {
    const chunks = []
    stream.on('data', (c)=>chunks.push(c))
    stream.on('end', ()=>resolve(Buffer.concat(chunks)))
    stream.on('error', reject)
  })
}

export default async function handler(req,res){
  if(req.method!=='POST') return res.status(405).end()
  const sigHeader = req.headers['x-nowpayments-signature'] || ''
  const secret = process.env.NOWPAYMENTS_WEBHOOK_SECRET || ''
  const buf = await buffer(req)
  const payload = buf.toString()
  if(!secret) return res.status(400).end()
  const hmac = crypto.createHmac('sha256', secret).update(payload).digest('hex')
  if(hmac !== sigHeader) return res.status(400).end()
  let data = {}
  try{ data = JSON.parse(payload) }catch(e){ return res.status(400).end() }
  try{
    if(data.payment_status){
      const provider_id = data.payment_id || data.id || (data.payment && data.payment.id)
      const status = data.payment_status
      const mapping = { finished: 'success', waiting: 'pending', failed: 'failed', canceled: 'failed' }
      const mapped = mapping[status] || status
      await supabase.from('transactions').update({ status: mapped }).eq('provider_id', provider_id)
      if(mapped === 'success'){
        const { data: tx } = await supabase.from('transactions').select('*').eq('provider_id', provider_id).limit(1).single()
        if(tx) await supabase.from('investments').insert([{ user_id: tx.user_id, amount: tx.amount, type: 'crypto' }])
      }
    }
    res.status(200).json({ok:true})
  }catch(e){
    console.error(e)
    res.status(500).end()
  }
}
