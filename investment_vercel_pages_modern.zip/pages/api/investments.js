import { supabase } from '../../lib/supabase'
import jwt from 'jsonwebtoken'

export default async function handler(req,res){
  const token = req.cookies?.token
  const secret = process.env.JWT_SECRET || 'dev_secret'
  let user = null
  try{ if(token) user = jwt.verify(token, secret) }catch(e){}
  if(user){
    const { data, error } = await supabase.from('investments').select('*').eq('user_id', user.id).order('created_at', {ascending:false})
    if(error) return res.status(500).json({error:'db'})
    return res.status(200).json({investments: data})
  }else{
    const { data, error } = await supabase.from('investments').select('*').limit(5).order('created_at', {ascending:false})
    if(error) return res.status(500).json({error:'db'})
    return res.status(200).json({investments: data})
  }
}
