import { supabase } from '../../lib/supabase'
import jwt from 'jsonwebtoken'

export default async function handler(req,res){
  const token = req.cookies?.token
  const secret = process.env.JWT_SECRET || 'dev_secret'
  try{
    const user = token ? jwt.verify(token, secret) : null
    if(!user || user.role!=='admin') return res.status(200).json({error:'forbidden'})
    const users = await supabase.from('users').select('*', {count:'exact', head:false})
    const investments = await supabase.from('investments').select('*', {count:'exact', head:false})
    const transactions = await supabase.from('transactions').select('*', {count:'exact', head:false})
    return res.status(200).json({users: users.count || 0, investments: investments.count || 0, transactions: transactions.count || 0})
  }catch(e){
    return res.status(500).json({error:'err'})
  }
}
