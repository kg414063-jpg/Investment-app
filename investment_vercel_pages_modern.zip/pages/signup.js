import {useState} from 'react'
import Router from 'next/router'
export default function Signup(){
  const [email,setEmail]=useState('')
  const [name,setName]=useState('')
  const [password,setPassword]=useState('')
  async function submit(e){
    e.preventDefault()
    const res = await fetch('/api/auth/signup',{method:'POST',headers:{'content-type':'application/json'},body:JSON.stringify({email,name,password})})
    if(res.ok) Router.push('/dashboard')
    else alert('Signup failed')
  }
  return (
    <div className="card" style={{maxWidth:520}}>
      <h2>Create an account</h2>
      <form onSubmit={submit}>
        <div className="form-row"><label className="small">Full name</label><input value={name} onChange={e=>setName(e.target.value)} required /></div>
        <div className="form-row"><label className="small">Email</label><input value={email} onChange={e=>setEmail(e.target.value)} type="email" required /></div>
        <div className="form-row"><label className="small">Password</label><input value={password} onChange={e=>setPassword(e.target.value)} type="password" required /></div>
        <div><button className="btn">Create account</button></div>
      </form>
    </div>
  )
}
