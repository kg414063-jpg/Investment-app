import useSWR from 'swr'
export default function Admin(){
  const {data} = useSWR('/api/admin/stats', (url)=>fetch(url).then(r=>r.json()))
  return (
    <div className="card">
      <h2>Admin Panel</h2>
      {!data && <p className="small">Loading...</p>}
      {data && !data.error && (
        <div>
          <p>Total users: {data.users}</p>
          <p>Total investments: {data.investments}</p>
          <p>Total transactions: {data.transactions}</p>
        </div>
      )}
      {data && data.error && <p className="small">You must be an admin to view stats.</p>}
    </div>
  )
}
