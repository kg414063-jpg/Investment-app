import {useState} from 'react'
import Router from 'next/router'
export default function Invest(){
  const [amount,setAmount]=useState(10)
  async function submit(e){
    e.preventDefault()
    const res = await fetch('/api/payments/create',{method:'POST',headers:{'content-type':'application/json'},body:JSON.stringify({amount})})
    if(!res.ok){ alert('Payment creation failed'); return }
    const body = await res.json()
    // open invoice URL if present
    const invoice = body.invoice || body.data
    const url = invoice.invoice_url || invoice.url || invoice.payment_url
    if(url) window.open(url,'_blank')
    else alert('Invoice created, check dashboard or transactions.')
  }
  return (
    <div className="card" style={{maxWidth:520}}>
      <h2>Invest with Crypto</h2>
      <form onSubmit={submit}>
        <div className="form-row"><label className="small">Amount (USD)</label><input type="number" value={amount} onChange={e=>setAmount(e.target.value)} min="1" /></div>
        <div><button className="btn">Create crypto invoice</button></div>
      </form>
    </div>
  )
}
