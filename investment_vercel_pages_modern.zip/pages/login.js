import {useState} from 'react'
import Router from 'next/router'
export default function Login(){
  const [email,setEmail]=useState('')
  const [password,setPassword]=useState('')
  async function submit(e){
    e.preventDefault()
    const res = await fetch('/api/auth/login',{method:'POST',headers:{'content-type':'application/json'},body:JSON.stringify({email,password})})
    if(res.ok) Router.push('/dashboard')
    else alert('Login failed')
  }
  return (
    <div className="card" style={{maxWidth:520}}>
      <h2>Sign in</h2>
      <form onSubmit={submit}>
        <div className="form-row"><label className="small">Email</label><input value={email} onChange={e=>setEmail(e.target.value)} required /></div>
        <div className="form-row"><label className="small">Password</label><input type="password" value={password} onChange={e=>setPassword(e.target.value)} required /></div>
        <div style={{display:'flex',gap:8}}><button className="btn">Sign in</button><a href="/signup" className="btn-ghost" style={{alignSelf:'center'}}>Sign up</a></div>
      </form>
    </div>
  )
}
