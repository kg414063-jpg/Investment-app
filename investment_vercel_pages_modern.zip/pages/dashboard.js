import useSWR from 'swr'
export default function Dashboard(){
  const {data,mutate} = useSWR('/api/investments', (url)=>fetch(url).then(r=>r.json()))
  return (
    <div className="grid">
      <div className="card">
        <h2>Your Investments</h2>
        {!data && <p className="small">Loading...</p>}
        {data && data.investments && (
          <ul>
            {data.investments.map(i=>(<li key={i.id}>{i.type} — ${i.amount} <span className="small">({i.created_at || i.date})</span></li>))}
          </ul>
        )}
      </div>
      <aside className="card">
        <h3>Quick actions</h3>
        <div style={{display:'flex',flexDirection:'column',gap:8}}>
          <a className="btn" href="/invest">Invest Now</a>
          <a className="btn-ghost" href="/admin">Admin</a>
        </div>
      </aside>
    </div>
  )
}
