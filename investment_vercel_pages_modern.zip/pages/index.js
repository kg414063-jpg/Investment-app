import Link from 'next/link'
export default function Home(){
  return (
    <div className="card">
      <h1>Investly — Modern Pages Router</h1>
      <p className="small">A modernized Next.js (Pages Router) investment dashboard ready for Vercel.</p>
      <div style={{marginTop:16}}>
        <Link href='/dashboard'><a className="btn">Go to Dashboard</a></Link>
      </div>
    </div>
  )
}
