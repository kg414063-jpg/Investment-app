import Link from 'next/link'
export default function Header({user}){
  return (
    <header className="header">
      <div className="brand"><Link href="/"><a style={{color:'inherit',textDecoration:'none'}}>Investly</a></Link></div>
      <nav className="nav">
        <Link href="/"><a className="small">Home</a></Link>
        <Link href="/dashboard"><a className="small">Dashboard</a></Link>
        <Link href="/invest"><a className="small">Invest</a></Link>
        {user ? <Link href="/api/auth/logout"><a className="small">Logout</a></Link> : <Link href="/login"><a className="small">Login</a></Link>}
        <Link href="/admin"><a className="small">Admin</a></Link>
      </nav>
    </header>
  )
}
