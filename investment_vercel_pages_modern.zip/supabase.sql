-- Supabase schema for Investment Dashboard (run in Supabase SQL editor)
create table users (
  id serial primary key,
  email text unique not null,
  password_hash text not null,
  role text default 'user',
  name text
);

create table investments (
  id serial primary key,
  user_id integer references users(id),
  amount numeric,
  type text,
  created_at timestamptz default now()
);

create table transactions (
  id serial primary key,
  user_id integer references users(id),
  amount numeric,
  status text,
  provider text,
  provider_id text,
  created_at timestamptz default now()
);
